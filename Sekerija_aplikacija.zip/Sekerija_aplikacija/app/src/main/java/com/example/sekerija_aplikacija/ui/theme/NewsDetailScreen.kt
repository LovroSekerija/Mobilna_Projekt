package com.example.sekerija_aplikacija.ui.theme

// ui/screens/NewsDetailScreen.kt


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import com.example.sekerija_aplikacija.ui.theme.NewsItem




@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsDetailScreen(
    newsItem: NewsItem,
    onBackClick: () -> Unit,
    onShareClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "FIGHT ZONE",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFD32F2F),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF121212))
                .padding(paddingValues)
        ) {
            item {
                // SLIKA
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(
                            ImageRequest.Builder(LocalContext.current)
                                .data(newsItem.imageUrl + newsItem.id + "?large")
                                .build()
                        ),
                        contentDescription = newsItem.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // FEATURED BADGE
                    if (newsItem.isFeatured) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(16.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFD32F2F))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "FEATURED",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // SADRŽAJ
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // KATEGORIJA
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFD32F2F))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = newsItem.category.uppercase(),
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // NASLOV
                    Text(
                        text = newsItem.title,
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 32.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // META INFORMACIJE
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // AUTOR
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Author",
                                tint = Color(0xFF888888),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = newsItem.author.ifEmpty { "Fight Zone Staff" },
                                color = Color(0xFF888888),
                                fontSize = 14.sp
                            )
                        }

                        // DATUM
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = "Date",
                                tint = Color(0xFF888888),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = newsItem.date.ifEmpty { newsItem.timeAgo },
                                color = Color(0xFF888888),
                                fontSize = 14.sp
                            )
                        }

                        // VRIJEME ČITANJA
                        Text(
                            text = newsItem.readTime,
                            color = Color(0xFF888888),
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // PUN TEKST VIJESTI
                    Text(
                        text = newsItem.fullContent.ifEmpty { getSampleFullContent(newsItem) },
                        color = Color(0xFFCCCCCC),
                        fontSize = 16.sp,
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    // STATISTIKE
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF1E1E1E)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Visibility,
                                    contentDescription = "Views",
                                    tint = Color(0xFFD32F2F),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = newsItem.views,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Views",
                                    color = Color(0xFF888888),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    // SHARE BUTTON
                    Button(
                        onClick = onShareClick,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFD32F2F)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SHARE THIS ARTICLE",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// Pomoćna funkcija za placeholder sadržaj
private fun getSampleFullContent(newsItem: NewsItem): String {
    return when (newsItem.category) {
        "MMA" -> "The championship showdown is set to be one of the most anticipated events of the year. Both fighters have been on a collision course for months, with training camps going perfectly according to plan. The main event features two of the most dominant champions in recent history...\n\nExperts predict this could be a fight for the ages, with both athletes having something to prove. The undercard is also stacked with rising prospects looking to make their mark on the sport."
        "Boxing" -> "The heavyweight clash promises fireworks as two of the hardest hitters in the division square off. With knockout power in both hands, this fight isn't expected to go the distance. The buildup has been intense, with both fighters exchanging words at press conferences...\n\nThe boxing world is divided on who will emerge victorious, making this one of the most unpredictable matchups in recent memory."
        "Kickboxing" -> "The world championship bout features technical mastery at its finest. Both competitors are known for their precision striking and incredible endurance. This fight represents the pinnacle of kickboxing excellence...\n\nFans can expect a display of martial arts at its highest level, with combinations and techniques that redefine what's possible in the sport."
        else -> "The upcoming event promises to deliver excitement and drama for fight fans worldwide. Stay tuned for more updates as we get closer to fight night..."
    }
}

@Preview(showBackground = true)
@Composable
fun NewsDetailScreenPreview() {
    MaterialTheme {
        NewsDetailScreen(
            newsItem = NewsItem(
                id = 1,
                title = "Championship Showdown: Title Fight Set for January",
                category = "MMA",
                timeAgo = "2 hours ago",
                views = "1.2K",
                author = "John Fight Analyst",
                date = "Dec 15, 2024",
                fullContent = "Detailed content about the championship fight...",
                isFeatured = true
            ),
            onBackClick = {},
            onShareClick = {}
        )
    }
}