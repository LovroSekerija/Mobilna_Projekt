package com.example.sekerija_aplikacija

import IntroScreen
import MainContent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sekerija_aplikacija.ui.theme.Sekerija_aplikacijaTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.animation.core.tween
import kotlinx.coroutines.delay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.alpha

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Sekerija_aplikacijaTheme {
                // STATE da pratimo na kojem smo screenu
                var showIntroScreen by remember { mutableStateOf(false) }

                if (showIntroScreen) {
                    // Ako je true, pokaži IntroScreen sa vijestima
                    IntroScreen(
                        onBackClick = {
                            showIntroScreen = false // Vrati na početni
                        }
                    )
                } else {
                    // Ako je false, pokaži StartScreen
                    StartScreen(
                        onEnterClick = {
                            showIntroScreen = true // Prijeđi na vijesti
                        }
                    )
                }
            }
        }
    }
}
// OVO DODAJ U MainActivity.kt ispod StartScreen funkcije:

var sliderImages=listOf(
    R.drawable.conor,
    R.drawable.rico,
    R.drawable.floyd,
    R.drawable.rodtang,
    R.drawable.charles,
    R.drawable.stipe
)


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntroScreen(onBackClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        // Header BEZ BACK GUMBA
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .background(Color(0xFFD32F2F)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "FIGHT ZONE",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        // Lista vijesti
        MainContent()
    }
}

// Ostali kod za IntroScreen (CategorySection, MainContent, NewsCard)
// kopiraš iz tvog postojećeg koda

@Composable
fun StartScreen(onEnterClick: () -> Unit) {
    // Trenutna slika
    var currentImage by remember { mutableStateOf(0) }

    // Alpha za fade (1f = vidljivo, 0f = nevidljivo)
    var imageAlpha by remember { mutableStateOf(1f) }

    // Animacija alpha vrijednosti
    val animatedAlpha by animateFloatAsState(
        targetValue = imageAlpha,
        animationSpec = androidx.compose.animation.core.tween(1000) // 1 sekunda animacije
    )

    // Mijenja slike sa fade efektom
    LaunchedEffect(currentImage) {
        while (true) {
            delay(4000) // Čeka 4 sekunde

            // Fade out (nestaje)
            imageAlpha = 0f
            delay(1000) // Čeka da se fade out završi (1 sekunda)

            // Promijeni sliku
            currentImage = (currentImage + 1) % sliderImages.size

            // Fade in (pojavljuje se)
            imageAlpha = 1f
            delay(1000) // Čeka da se fade in završi
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // SLIKA SA FADE ANIMACIJOM
        Image(
            painter = painterResource(id = sliderImages[currentImage]),
            contentDescription = "Background",
            modifier = Modifier
                .fillMaxSize()
                .alpha(animatedAlpha), // ← OVO JE ANIMACIJA
            contentScale = ContentScale.Crop,
            alpha = 0.8f
        )

        // TAMNI PRELIV
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.4f))
        )

        // TEKST I GUMB
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "FIGHT ZONE",
                color = Color.White,
                fontSize = 48.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Ultimate Combat Sports Hub",
                color = Color(0xFFFF5252),
                fontSize = 18.sp
            )

            Spacer(modifier = Modifier.height(40.dp))

            Text(
                text = "Najnovije vijesti iz svijeta borilačkog sporta. Sve na jednom mjestu za fanove najopasnijeg sporta",
                color = Color.White,
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(60.dp))

            Button(
                onClick = onEnterClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF5252)
                )
            ) {
                Text(
                    text = "ENTER ARENA",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "© 2024 Fight Zone",
                color = Color(0xFFAAAAAA),
                fontSize = 12.sp
            )
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun StartScreenPreview() {
    Sekerija_aplikacijaTheme {
        StartScreen(onEnterClick = {})
    }
}
// OVAJ DIO OBAVEZNO UKLONI ILI ZAKOMENTIRAŠ AKO TI STVARA PROBLEM:
/*
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Sekerija_aplikacijaTheme {
        Greeting("Android")
    }
}
*/