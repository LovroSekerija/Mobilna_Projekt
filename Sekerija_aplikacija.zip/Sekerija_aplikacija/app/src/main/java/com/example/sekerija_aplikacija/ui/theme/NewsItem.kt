package com.example.sekerija_aplikacija.ui.theme

data class NewsItem(
    val id: Int,
    val title: String,
    val category: String,
    val timeAgo: String,
    val views: String,
    val imageUrl: String = "https://picsum.photos/400/200?random=",
    val excerpt: String = "Brief summary of the news...",
    val isFeatured: Boolean = false,
    val fullContent: String="",
    val author: String="",
    val date: String="",
    val readTime: String="3 min read"
)
