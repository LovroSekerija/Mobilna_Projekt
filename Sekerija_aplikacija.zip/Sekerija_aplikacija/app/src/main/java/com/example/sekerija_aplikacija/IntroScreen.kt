
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import com.example.sekerija_aplikacija.ui.theme.Sekerija_aplikacijaTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.sekerija_aplikacija.ui.theme.NewsItem
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.request.ImageRequest
import coil.compose.rememberAsyncImagePainter



@OptIn(ExperimentalMaterial3Api::class)
@Composable

fun IntroScreen(onBackClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .background(Color(0xFFD32F2F)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "FIGHT ZONE",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        // Kategorije


        // Lista vijesti
        MainContent()
    }
}

@Composable
fun CategorySection() {
    val categories = listOf("All", "MMA", "Boxing", "Kickboxing")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        categories.forEach { category ->
            CategoryChip(category = category, isSelected = category == "All")
        }
    }
}

@Composable
fun CategoryChip(category: String, isSelected: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (isSelected) Color(0xFFD32F2F) else Color(0xFF2C2C2C)
            )
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = category,
            color = if (isSelected) Color.White else Color(0xFFAAAAAA),
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
@Composable
fun MainContent() {
    val newsItems = listOf(
        NewsItem(
            id = 1,
            title = "Championship Showdown",
            category = "MMA",
            timeAgo = "2 hours ago",
            views = "1.2K",
            isFeatured = true
        ),
        NewsItem(
            id = 2,
            title = "Undefeated Prospect Calls Out Division Champion",
            category = "MMA",
            timeAgo = "3 hours ago",
            views = "1.2K",
            isFeatured = false
        ),
        NewsItem(
            id = 3,
            title = "Heavyweight Clash Announced",
            category = "Boxing",
            timeAgo = "5 hours ago",
            views = "890",
            isFeatured = false
        ),
        NewsItem(
            id = 4,
            title = "Kickboxing World Championship",
            category = "Kickboxing",
            timeAgo = "1 day ago",
            views = "2.1K",
            isFeatured = false
        ),
        NewsItem(
            id = 5,
            title = "Bantamweight Tournament Finals",
            category = "MMA",
            timeAgo = "1 day ago",
            views = "1.5K",
            isFeatured = true
        ),
        NewsItem(
            id = 6,
            title = "Legacy Fight: Veteran vs Rising Star",
            category = "Boxing",
            timeAgo = "2 days ago",
            views = "3.4K",
            isFeatured = true
        ),
        NewsItem(
            id = 7,
            title = "Muay Thai Grand Prix Results",
            category = "Kickboxing",
            timeAgo = "2 days ago",
            views = "980",
            isFeatured = false
        ),
        NewsItem(
            id = 8,
            title = "Women's Strawweight Title Fight",
            category = "MMA",
            timeAgo = "3 days ago",
            views = "2.7K",
            isFeatured = false
        )
    )



    LazyColumn(
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            CategorySection()
        }

        items(newsItems) { newsItem ->
            NewsCard(newsItem = newsItem)
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
@Composable
fun NewsCard(newsItem: NewsItem) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E1E1E)
        )
    ) {
        Column {
            // Slika
            Box(modifier = Modifier.height(200.dp)) {
                Image(
                    painter = rememberAsyncImagePainter(
                        ImageRequest.Builder(LocalContext.current)
                            .data(newsItem.imageUrl + newsItem.id)
                            .build()
                    ),
                    contentDescription = newsItem.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)),
                    contentScale = ContentScale.Crop
                )

                // Badge za featured
                if (newsItem.isFeatured) {
                    Box(
                        modifier = Modifier
                            .padding(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFD32F2F))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "FEATURED",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Sadržaj
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Naslov i kategorija
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = newsItem.title,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFD32F2F))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = newsItem.category,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Opis
                Text(
                    text = if (newsItem.isFeatured) {
                        "**Championship Showdown:** Title Fight Set for January"
                    } else {
                        "Undefeated Prospect Calls Out Division Champion"
                    },
                    color = Color(0xFFCCCCCC),
                    fontSize = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Vrijeme i pregledi - ISPRAVLJEN DIO
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = newsItem.timeAgo,
                        color = Color(0xFF888888),
                        fontSize = 12.sp
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FavoriteBorder,
                            contentDescription = "Views",
                            tint = Color(0xFF888888),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = newsItem.views,
                            color = Color(0xFF888888),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
)
@Composable
fun IntroScreenPreview() {
    Sekerija_aplikacijaTheme {
        IntroScreen(
            onBackClick = {} // ← SAMO PRAZNA FUNKCIJA, NE MOŽEŠ KORISTITI showIntroScreen
        )
    }
}